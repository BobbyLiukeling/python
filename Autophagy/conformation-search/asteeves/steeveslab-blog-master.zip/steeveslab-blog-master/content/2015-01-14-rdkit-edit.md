Title: Editing, merging, and replacing molecules in RDKit
Date: 2015-01-14 12:00
Category: IPython notebook
Tags: python, notebook, rdkit, substructure, editing, merging, combining
Slug: editing-in-rdkit
Authors: Adam Steeves

{% img png /images/molecule_edit.png %}


{% notebook RDKit_KulikLab_07_Edit.ipynb cells[1:] %}


