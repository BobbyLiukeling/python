Title: Lists of molecules in RDKit
Date: 2015-01-12 16:00
Category: IPython notebook
Tags: python, notebook, rdkit, lists, list comprehension
Slug: lists-in-rdkit
Authors: Adam Steeves

{% img png /images/molecule_list_image.png %}

{% notebook RDKit_KulikLab_04_Lists.ipynb cells[1:] %}


