Title: No time like the present
Date: 2015-01-07 19:30
Category: IPython notebook
Tags: python, notebook, blogging
Slug: like-the-present
Authors: Adam Steeves

I have heard that it is possible to assemble a blog using the IPython notebook.
I think I might give that a try. 

{% notebook test_notebook.ipynb cells[1:] %}

How are my "quotes" now?
