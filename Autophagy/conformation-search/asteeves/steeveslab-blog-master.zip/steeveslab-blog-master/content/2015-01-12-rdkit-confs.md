Title: Multiple conformations of a molecule in RDKit
Date: 2015-01-12 13:00
Category: IPython notebook
Tags: python, notebook, rdkit, optimization, conformations, alignment
Slug: conformations-in-rdkit
Authors: Adam Steeves

{% img png /images/ibuprofen_multiconf.png %}

{% notebook RDKit_KulikLab_03_MultiConf.ipynb cells[1:] %}


